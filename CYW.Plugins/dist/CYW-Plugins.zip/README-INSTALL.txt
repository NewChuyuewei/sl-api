CYW's Plugins - release package
===============================

Extract this zip INTO the LabAPI folder of your SCP:SL dedicated server:

    %APPDATA%\SCP Secret Laboratory\LabAPI\        (Windows)
    ~/.config/SCP Secret Laboratory/LabAPI/        (Linux)

The archive mirrors the LabAPI layout:

    plugins/global/        plugin assemblies
    dependencies/global/   shared dependency assemblies (0Harmony, *.Core, ...)

After extraction, restart the server.